# Přehled všech změněných textů

## gen.json: stat.meleeKnockback.label

**EN:** melee knockback

**Původně:** odhození zblízka

**Nově:** odhození při Melee

## gen.json: stat.passiveSlots.label

**EN:** passive slots

**Původně:** pozice pro pasivní schopnosti

**Nově:** pozice pro pasivní předměty

## gen.json: stat.powerUpRate.label

**EN:** power-up drops

**Původně:** četnost bonusů

**Nově:** četnost padání bonusů

## gen.json: quest.what.chickens.other

**EN:** chickens

**Původně:** kuřat

**Nově:** Chicken

## gen.json: quest.what.goblins.other

**EN:** goblins

**Původně:** goblinů

**Nově:** Goblin

## gen.json: quest.what.imps.other

**EN:** imps

**Původně:** rarášků

**Nově:** Imp

## gen.json: quest.what.ghosts.other

**EN:** ghosts

**Původně:** duchů

**Nově:** Ghost

## gen.json: quest.what.loar_shades.other

**EN:** Loar Shades

**Původně:** Loar Shades

**Nově:** Loar Shade

## gen.json: quest.what.feral_vampyres.other

**EN:** Feral Vampyres

**Původně:** Feral Vampyres

**Nově:** Feral Vampyre

## gen.json: quest.what.scarab_swarms.other

**EN:** scarab swarms

**Původně:** rojů skarabů

**Nově:** Scarab Swarm

## gen.json: quest.what.dagannoths.other

**EN:** dagannoths

**Původně:** dagannoths

**Nově:** Dagannoth

## gen.json: quest.what.monkeys.other

**EN:** monkeys

**Původně:** opic

**Nově:** Monkey

## gen.json: quest.what.lizardmen.other

**EN:** lizardmen

**Původně:** ještěrců

**Nově:** Lizardman

## gen.json: quest.what.naguas.other

**EN:** naguas

**Původně:** naguas

**Nově:** nagua

## gen.json: quest.what.ghasts.other

**EN:** ghasts

**Původně:** přízraků

**Nově:** Ghast

## gen.json: quest.what.aviansies.other

**EN:** aviansies

**Původně:** aviansies

**Nově:** Aviansie

## gen.json: quest.what.nibblers.other

**EN:** nibblers

**Původně:** okusovačů

**Nově:** Jal-Nib

## gen.json: quest.what.sleepwalkers.other

**EN:** sleepwalkers

**Původně:** náměsíčníků

**Nově:** Sleepwalker

## gen.json: quest.what.rats.other

**EN:** rats

**Původně:** krys

**Nově:** Rat

## items.json: weapon.scimitar.level.3.desc

**EN:** +5 damage. +0.2 knockback.

**Původně:** +5 poškození. +0,2 odhození.

**Nově:** +5 poškození. +0.2 odhození.

## items.json: weapon.scimitar.level.5.desc

**EN:** +3 damage. +0.2 knockback.

**Původně:** +3 poškození. +0,2 odhození.

**Nově:** +3 poškození. +0.2 odhození.

## items.json: weapon.scimitar.level.7.desc

**EN:** +3 damage, +8% reach. +0.2 knockback.

**Původně:** +3 poškození, +8% dosah. +0,2 odhození.

**Nově:** +3 poškození, +8 % k dosahu. +0.2 odhození.

## items.json: weapon.abyssal_whip.desc

**EN:** Evolved scimitar. Lashes on both sides, fast and far.

**Původně:** Vylepšená Scimitar. Rychle šlehá na obě strany s velkým dosahem.

**Nově:** Vyvinutá Scimitar. Rychle šlehá na obě strany s velkým dosahem.

## items.json: weapon.abyssal_whip.level.3.desc

**EN:** +2 damage. +0.2 knockback.

**Původně:** +2 poškození. +0,2 odhození.

**Nově:** +2 poškození. +0.2 odhození.

## items.json: weapon.flames_of_zamorak.desc

**EN:** Evolved fire spells. Pillars of Zamorak's fire burst up under enemies all around you; bosses and elites are burned three times more.

**Původně:** Vylepšené Fire spells. Pod nepřáteli všude kolem vás vyšlehávají sloupy Zamorakova ohně. Bossové a elitní nepřátelé utrpí trojnásobné poškození.

**Nově:** Vyvinuté Fire spells. Pod nepřáteli všude kolem vás vyšlehávají sloupy Zamorakova ohně. Bossové a elitní nepřátelé utrpí trojnásobné poškození.

## items.json: weapon.toktz_xil_ul.desc

**EN:** Evolved throwing knives. Obsidian rings that go through everything.

**Původně:** Vylepšené Throwing knives. Obsidiánové kruhy proletí vším.

**Nově:** Vyvinuté Throwing knives. Obsidiánové kruhy proletí vším.

## items.json: weapon.ice_barrage.desc

**EN:** Evolved Ice Burst. A huge freezing blast.

**Původně:** Vylepšený Ice Burst. Obrovský mrazivý výbuch.

**Nově:** Vyvinutý Ice Burst. Obrovský mrazivý výbuch.

## items.json: weapon.smoke_barrage.desc

**EN:** Evolved Smoke Burst. A huge blast of smoke that poisons hard and long.

**Původně:** Vylepšený Smoke Burst. Obrovský kouřový výbuch se silným jedem a dlouhým trváním.

**Nově:** Vyvinutý Smoke Burst. Obrovský kouřový výbuch se silným jedem a dlouhým trváním.

## items.json: weapon.shadow_barrage.desc

**EN:** Evolved Shadow Burst. A huge blast of shadow; what it hits takes 30% more damage for a while.

**Původně:** Vylepšený Shadow Burst. Obrovský stínový výbuch; zasažení nepřátelé po určitou dobu utrpí o 30 % větší poškození.

**Nově:** Vyvinutý Shadow Burst. Obrovský stínový výbuch; zasažení nepřátelé po určitou dobu utrpí o 30 % větší poškození.

## items.json: weapon.blood_barrage.desc

**EN:** Evolved Blood Burst. A huge blast of blood. Now and then a hit heals you by 4.

**Původně:** Vylepšený Blood Burst. Obrovský krvavý výbuch. Občas vám zásah obnoví 4 životy.

**Nově:** Vyvinutý Blood Burst. Obrovský krvavý výbuch. Občas vám zásah obnoví 4 životy.

## items.json: weapon.undead_grasp.desc

**EN:** Evolved Saradomin Strike. Undead hands burst out of the ground and hold what they grab.

**Původně:** Vylepšený Saradomin Strike. Ze země vyrážejí nemrtvé ruce a zadržují chycené nepřátele.

**Nově:** Vyvinutý Saradomin Strike. Ze země vyrážejí nemrtvé ruce a zadržují chycené nepřátele.

## items.json: weapon.two_handed_sword.desc

**EN:** A heavy sweep in front of you. Upgrades through the metals to dragon.

**Původně:** Silný obloukový útok před vámi. Postupně se vylepšuje na meče z lepších kovů až po Dragon 2h sword.

**Nově:** Silný obloukový útok před vámi. Postupně se vylepšuje přes jednotlivé kovy až na dragon.

## items.json: weapon.two_handed_sword.level.3.desc

**EN:** +4 damage. +0.2 knockback.

**Původně:** +4 poškození. +0,2 odhození.

**Nově:** +4 poškození. +0.2 odhození.

## items.json: weapon.two_handed_sword.level.5.desc

**EN:** +4 damage. +0.2 knockback.

**Původně:** +4 poškození. +0,2 odhození.

**Nově:** +4 poškození. +0.2 odhození.

## items.json: weapon.two_handed_sword.level.7.desc

**EN:** Sweeps a wider arc. +0.2 knockback.

**Původně:** Zasahuje v širším oblouku. +0,2 odhození.

**Nově:** Zasahuje v širším oblouku. +0.2 odhození.

## items.json: weapon.colossal_blade.desc

**EN:** Evolved 2h sword. A huge sweep on both sides. Bosses and elites are hit again.

**Původně:** Vylepšený 2h sword. Obrovský obloukový útok na obě strany. Bossy a elitní nepřátele zasáhne ještě jednou.

**Nově:** Vyvinutý 2h sword. Obrovský obloukový útok na obě strany. Bossy a elitní nepřátele zasáhne ještě jednou.

## items.json: weapon.colossal_blade.level.3.desc

**EN:** +3 damage. +0.2 knockback.

**Původně:** +3 poškození. +0,2 odhození.

**Nově:** +3 poškození. +0.2 odhození.

## items.json: weapon.shortbow.desc

**EN:** Shoots arrows at the nearest enemy. Upgrades through the woods to magic, the arrows through the metals.

**Původně:** Střílí šípy na nejbližšího nepřítele. Luk se postupně vylepšuje až na Magic shortbow a šípy na lepší kovy.

**Nově:** Střílí šípy na nejbližšího nepřítele. Luk se vylepšuje přes jednotlivé druhy dřeva až na Magic shortbow, šípy přes jednotlivé kovy.

## items.json: weapon.dark_bow.desc

**EN:** Evolved shortbow. Two heavy dragon arrows at a time, Descent of Dragons, that blow up where they hit.

**Původně:** Vylepšený Shortbow. Vystřeluje dvojice těžkých Dragon arrows útokem Descent of Dragons, které při zásahu vybuchují.

**Nově:** Vyvinutý Shortbow. Útok Descent of Dragons vystřelí dvě těžké Dragon arrows, které při zásahu vybuchnou.

## items.json: weapon.chain_hit_axes.desc

**EN:** Evolved throwing axes. Morrigan's axes chain-hit through a crowd, bouncing on to up to nine more.

**Původně:** Vylepšené Throwing axes. Morriganiny sekery se řetězově odrážejí davem až na devět dalších nepřátel.

**Nově:** Vyvinuté Throwing axes. Morriganiny sekery se řetězově odrážejí davem až na devět dalších nepřátel.

## items.json: weapon.astral_runes.desc

**EN:** Evolved elemental runes. Vengeance's runes circle you and never stop.

**Původně:** Vylepšené Elemental runes. Runy Vengeance vás obíhají bez přestání.

**Nově:** Vyvinuté Elemental runes. Runy Vengeance vás obíhají bez přestání.

## items.json: weapon.scythe_of_vitur.level.3.desc

**EN:** +14% reach. +0.2 knockback.

**Původně:** +14% dosah. +0,2 odhození.

**Nově:** +14 % k dosahu. +0.2 odhození.

## items.json: weapon.scythe_of_vitur.level.5.desc

**EN:** +9 damage. +0.2 knockback.

**Původně:** +9 poškození. +0,2 odhození.

**Nově:** +9 poškození. +0.2 odhození.

## items.json: weapon.holy_scythe_of_vitur.level.3.desc

**EN:** +14% reach. +0.2 knockback.

**Původně:** +14% dosah. +0,2 odhození.

**Nově:** +14 % k dosahu. +0.2 odhození.

## items.json: weapon.holy_scythe_of_vitur.level.5.desc

**EN:** +8 damage. +0.2 knockback.

**Původně:** +8 poškození. +0,2 odhození.

**Nově:** +8 poškození. +0.2 odhození.

## items.json: weapon.sanguine_scythe.desc

**EN:** Evolved Scythe of Vitur. A wider sweep. Bosses and elites are hit three times, and every fourth sweep is Blood Harvest, which heals you.

**Původně:** Vylepšená Scythe of Vitur se širším záběrem. Bossy a elitní nepřátele zasáhne třikrát. Každý čtvrtý útok je Blood Harvest a léčí vás.

**Nově:** Vyvinutá Scythe of Vitur se širším záběrem. Bossy a elitní nepřátele zasáhne třikrát. Každý čtvrtý útok je Blood Harvest a léčí vás.

## items.json: weapon.sanguine_scythe.level.3.desc

**EN:** +4 damage. +0.2 knockback.

**Původně:** +4 poškození. +0,2 odhození.

**Nově:** +4 poškození. +0.2 odhození.

## items.json: weapon.armadyl_godsword.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.armadyl_godsword.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.bandos_godsword.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.bandos_godsword.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.saradomin_godsword.desc

**EN:** A heavy two-handed sweep. Every third swing is Healing Blade: heals you by half the damage it does, up to 3.

**Původně:** Silný obouruční obloukový útok. Každý třetí úder je Healing Blade: obnoví vám polovinu způsobeného poškození, nejvýše 3 životy.

**Nově:** Silný obouruční obloukový útok. Každý třetí úder je Healing Blade: obnoví životy ve výši poloviny způsobeného poškození, nejvýše 3 životy.

## items.json: weapon.saradomin_godsword.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.saradomin_godsword.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.zamorak_godsword.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.zamorak_godsword.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.godsword.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.godsword.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.ancient_godsword.desc

**EN:** Evolved godsword. Every third swing is Blood Sacrifice: it hits everything around you and heals you.

**Původně:** Vylepšený Godsword. Každý třetí úder je Blood Sacrifice: zasáhne vše kolem vás a léčí vás.

**Nově:** Vyvinutý Godsword. Každý třetí úder je Blood Sacrifice: zasáhne vše kolem vás a léčí vás.

## items.json: weapon.ancient_godsword.level.3.desc

**EN:** +11 damage. +0.2 knockback.

**Původně:** +11 poškození. +0,2 odhození.

**Nově:** +11 poškození. +0.2 odhození.

## items.json: weapon.dragon_claws.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.dragon_claws.level.5.desc

**EN:** +2 damage a slash; also slashes behind you. +0.2 knockback.

**Původně:** +2 poškození při každém seknutí; seká také za vámi. +0,2 odhození.

**Nově:** +2 poškození při každém seknutí; seká také za vámi. +0.2 odhození.

## items.json: weapon.burning_claws.desc

**EN:** Evolved Dragon claws. Four quick slashes each time, and every third set burns what it hits.

**Původně:** Vylepšené Dragon claws. Čtyři rychlá seknutí; každá třetí série zapálí zasažené cíle.

**Nově:** Vyvinuté Dragon claws. Čtyři rychlá seknutí; každá třetí série zapálí zasažené cíle.

## items.json: weapon.burning_claws.level.3.desc

**EN:** +1 damage. +0.2 knockback.

**Původně:** +1 poškození. +0,2 odhození.

**Nově:** +1 poškození. +0.2 odhození.

## items.json: weapon.ivandis_flail.level.3.desc

**EN:** Also flails behind you. +0.2 knockback.

**Původně:** Zasahuje také za vámi. +0,2 odhození.

**Nově:** Zasahuje také za vámi. +0.2 odhození.

## items.json: weapon.ivandis_flail.level.5.desc

**EN:** +5 damage. +0.2 knockback.

**Původně:** +5 poškození. +0,2 odhození.

**Nově:** +5 poškození. +0.2 odhození.

## items.json: weapon.blisterwood_flail.desc

**EN:** Evolved Ivandis flail. Vampyres and the undead are hit 50% harder, and pass the hit on to three more of their kind nearby.

**Původně:** Vylepšený Ivandis flail. Upírům a nemrtvým způsobuje o 50 % větší poškození a přenese zásah na tři další blízké cíle stejného druhu.

**Nově:** Vyvinutý Ivandis flail. Upírům a nemrtvým způsobuje o 50 % větší poškození a přenese zásah na tři další blízké cíle stejného druhu.

## items.json: weapon.blisterwood_flail.level.3.desc

**EN:** +2 damage. +0.2 knockback.

**Původně:** +2 poškození. +0,2 odhození.

**Nově:** +2 poškození. +0.2 odhození.

## items.json: weapon.osmumtens_fang.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.osmumtens_fang.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.ghrazi_rapier.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.ghrazi_rapier.level.5.desc

**EN:** +7 damage. +0.2 knockback.

**Původně:** +7 poškození. +0,2 odhození.

**Nově:** +7 poškození. +0.2 odhození.

## items.json: weapon.keris_partisan.level.3.desc

**EN:** +12% reach. +0.2 knockback.

**Původně:** +12% dosah. +0,2 odhození.

**Nově:** +12 % k dosahu. +0.2 odhození.

## items.json: weapon.keris_partisan.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.keris_partisan_of_breaching.level.3.desc

**EN:** +12% reach. +0.2 knockback.

**Původně:** +12% dosah. +0,2 odhození.

**Nově:** +12 % k dosahu. +0.2 odhození.

## items.json: weapon.keris_partisan_of_breaching.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.keris_partisan_of_corruption.level.3.desc

**EN:** +12% reach. +0.2 knockback.

**Původně:** +12% dosah. +0,2 odhození.

**Nově:** +12 % k dosahu. +0.2 odhození.

## items.json: weapon.keris_partisan_of_corruption.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.keris_partisan_of_the_sun.level.3.desc

**EN:** +12% reach. +0.2 knockback.

**Původně:** +12% dosah. +0,2 odhození.

**Nově:** +12 % k dosahu. +0.2 odhození.

## items.json: weapon.keris_partisan_of_the_sun.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.keris_partisan_of_amascut.level.3.desc

**EN:** +12% reach. +0.2 knockback.

**Původně:** +12% dosah. +0,2 odhození.

**Nově:** +12 % k dosahu. +0.2 odhození.

## items.json: weapon.keris_partisan_of_amascut.level.5.desc

**EN:** +6 damage. +0.2 knockback.

**Původně:** +6 poškození. +0,2 odhození.

**Nově:** +6 poškození. +0.2 odhození.

## items.json: weapon.tzhaar_ket_om.level.3.desc

**EN:** +11% reach. +0.2 knockback.

**Původně:** +11% dosah. +0,2 odhození.

**Nově:** +11 % k dosahu. +0.2 odhození.

## items.json: weapon.tzhaar_ket_om.level.5.desc

**EN:** +13 damage. +0.2 knockback.

**Původně:** +13 poškození. +0,2 odhození.

**Nově:** +13 poškození. +0.2 odhození.

## items.json: weapon.dragon_warhammer.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.dragon_warhammer.level.5.desc

**EN:** +10 damage. +0.2 knockback.

**Původně:** +10 poškození. +0,2 odhození.

**Nově:** +10 poškození. +0.2 odhození.

## items.json: weapon.elder_maul.desc

**EN:** Evolved Dragon warhammer. A heavy sweep. Every third is Shockwave: it hits everything around you, and they take 30% more damage for 8s.

**Původně:** Vylepšený Dragon warhammer. Těžký obloukový útok. Každý třetí je Shockwave: zasáhne vše kolem vás a cíle po dobu 8 s utrpí o 30 % větší poškození.

**Nově:** Vyvinutý Dragon warhammer. Těžký obloukový útok. Každý třetí je Shockwave: zasáhne vše kolem vás a cíle po dobu 8 s utrpí o 30 % větší poškození.

## items.json: weapon.elder_maul.level.3.desc

**EN:** +5 damage. +0.2 knockback.

**Původně:** +5 poškození. +0,2 odhození.

**Nově:** +5 poškození. +0.2 odhození.

## items.json: weapon.dinhs_bulwark.level.3.desc

**EN:** +15% reach. +0.2 knockback.

**Původně:** +15% dosah. +0,2 odhození.

**Nově:** +15 % k dosahu. +0.2 odhození.

## items.json: weapon.dinhs_bulwark.level.5.desc

**EN:** +18 damage. +0.2 knockback.

**Původně:** +18 poškození. +0,2 odhození.

**Nově:** +18 poškození. +0.2 odhození.

## items.json: weapon.dinhs_blazing_bulwark.desc

**EN:** Evolved Dinh's bulwark. A slow bash all around you. Every third is Shield Bash: it reaches further and burns what it hits.

**Původně:** Vylepšený Dinh's bulwark. Pomalý úder do všech stran. Každý třetí je Shield Bash: dosáhne dál a zapálí zasažené cíle.

**Nově:** Vyvinutý Dinh's bulwark. Pomalý úder do všech stran. Každý třetí je Shield Bash: dosáhne dál a zapálí zasažené cíle.

## items.json: weapon.dinhs_blazing_bulwark.level.3.desc

**EN:** +1 damage. +0.2 knockback.

**Původně:** +1 poškození. +0,2 odhození.

**Nově:** +1 poškození. +0.2 odhození.

## items.json: weapon.dual_macuahuitl.level.3.desc

**EN:** Slashes a little faster. +0.2 knockback.

**Původně:** Seká o něco rychleji. +0,2 odhození.

**Nově:** Seká o něco rychleji. +0.2 odhození.

## items.json: weapon.dual_macuahuitl.level.5.desc

**EN:** +4 damage. +0.2 knockback.

**Původně:** +4 poškození. +0,2 odhození.

**Nově:** +4 poškození. +0.2 odhození.

## items.json: weapon.thunder_khopesh.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.thunder_khopesh.level.5.desc

**EN:** +8 damage. +0.2 knockback.

**Původně:** +8 poškození. +0,2 odhození.

**Nově:** +8 poškození. +0.2 odhození.

## items.json: weapon.corrupted_twisted_bow.desc

**EN:** Evolved Twisted bow. Shoots the toughest enemy in range, up to +180% on bosses, and bosses and elites are hit again.

**Původně:** Vylepšený Twisted bow. Střílí na nejodolnějšího nepřítele v dosahu, s bonusem až +180 % proti bossům. Bossy a elitní nepřátele zasáhne ještě jednou.

**Nově:** Vyvinutý Twisted bow. Střílí na nejodolnějšího nepřítele v dosahu, s bonusem až +180 % proti bossům. Bossy a elitní nepřátele zasáhne ještě jednou.

## items.json: weapon.armadyl_crossbow.desc

**EN:** Fires bolts at the nearest enemy that pass through it. One in five is enchanted: a ruby's takes a fifth of what's left of its hitpoints, a diamond's goes on through more, a dragonstone's burns.

**Původně:** Střílí průrazné šipky do kuše na nejbližšího nepřítele. Každá pátá je očarovaná: rubínová ubere pětinu zbývajících životů cíle, diamantová proletí více cíli a drahokamová zapaluje.

**Nově:** Střílí průrazné šipky na nejbližšího nepřítele. Každá má šanci jedna ku pěti na očarovaný účinek: Ruby bolts uberou pětinu zbývajících životů cíle, Diamond bolts proletí více cíli a Dragonstone bolts zapálí cíl.

## items.json: weapon.corrupted_bow.desc

**EN:** Evolved crystal bow. Corrupted arrows split into five where they first hit, and each goes on through one more.

**Původně:** Vylepšený Crystal bow. Zkažené šípy se při prvním zásahu rozdělí na pět a každý proletí ještě jedním nepřítelem.

**Nově:** Vyvinutý Crystal bow. Zkažené šípy se při prvním zásahu rozdělí na pět a každý proletí ještě jedním nepřítelem.

## items.json: weapon.corrupted_tumekens_shadow.desc

**EN:** Evolved Tumeken's shadow. Bigger blasts that pass through two enemies. 3.5x your damage bonus for its hits.

**Původně:** Vylepšený Tumeken's shadow. Větší výboje proletí dvěma nepřáteli. Pro své zásahy násobí váš bonus k poškození 3,5krát.

**Nově:** Vyvinutý Tumeken's shadow. Větší výboje proletí dvěma nepřáteli. Pro své zásahy násobí váš bonus k poškození 3.5krát.

## items.json: weapon.eldritch_nightmare_staff.desc

**EN:** Evolved Harmonised nightmare staff. Each Fire Surge splits into three more where it first hits.

**Původně:** Vylepšený Harmonised nightmare staff. Každý Fire Surge se při prvním zásahu rozdělí na tři další.

**Nově:** Vyvinutý Harmonised nightmare staff. Každý Fire Surge se při prvním zásahu rozdělí na tři další.

## items.json: weapon.inquisitors_mace.level.3.desc

**EN:** +13% reach. +0.2 knockback.

**Původně:** +13% dosah. +0,2 odhození.

**Nově:** +13 % k dosahu. +0.2 odhození.

## items.json: weapon.inquisitors_mace.level.5.desc

**EN:** +6 damage; also swings behind you. +0.2 knockback.

**Původně:** +6 poškození; útočí také za vámi. +0,2 odhození.

**Nově:** +6 poškození; útočí také za vámi. +0.2 odhození.

## items.json: weapon.sanguinesti_staff.desc

**EN:** Casts blood blasts at the nearest enemy. One hit in six heals you for half its damage, up to 2 hitpoints.

**Původně:** Sesílá krvavé výboje na nejbližšího nepřítele. Každý šestý zásah vás vyléčí za polovinu svého poškození, nejvýše o 2 životy.

**Nově:** Sesílá krvavé výboje na nejbližšího nepřítele. Každý zásah má šanci jedna ku šesti obnovit životy ve výši poloviny způsobeného poškození, nejvýše 2 životy.

## items.json: weapon.holy_sanguinesti_staff.desc

**EN:** Evolved Sanguinesti staff. Blood blasts that splash. One hit in four heals you for half its damage, up to 3 hitpoints.

**Původně:** Vylepšený Sanguinesti staff. Krvavé výboje s plošným zásahem. Každý čtvrtý zásah vás vyléčí za polovinu svého poškození, nejvýše o 3 životy.

**Nově:** Vyvinutá Sanguinesti staff. Krvavé výboje s plošným zásahem. Každý zásah má šanci jedna ku čtyřem obnovit životy ve výši poloviny způsobeného poškození, nejvýše 3 životy.

## items.json: util.super_attack.desc

**EN:** +15% weapon speed for 30 seconds.

**Původně:** +15 % rychlosti zbraní na 30 sekund.

**Nově:** +15 % rychlosti útoků na 30 sekund.

## items.json: util.saradomin_brew.desc

**EN:** Heals 18 hitpoints. +1.5 armour, but -15% damage, for 20 seconds.

**Původně:** Obnoví 18 životů. Na 20 sekund přidá 1,5 zbroje, ale sníží poškození o 15 %.

**Nově:** Obnoví 18 životů. Na 20 sekund přidá 1.5 zbroje, ale sníží poškození o 15 %.

## items.json: util.super_combat_potion.desc

**EN:** +25% damage, +1 armour and +10% weapon speed for 30 seconds.

**Původně:** +25 % poškození, +1 zbroje a +10 % rychlosti zbraní na 30 sekund.

**Nově:** +25 % poškození, +1 zbroje a +10 % rychlosti útoků na 30 sekund.

## items.json: util.bastion_potion.desc

**EN:** +1 projectile, +20% projectile speed and +1.5 armour for 30 seconds.

**Původně:** +1 projektil, +20 % rychlosti projektilů a +1,5 zbroje na 30 sekund.

**Nově:** +1 projektil, +20 % rychlosti projektilů a +1.5 zbroje na 30 sekund.

## items.json: util.battlemage_potion.desc

**EN:** +25% area, +25% effect duration and +1.5 armour for 30 seconds.

**Původně:** +25 % plochy účinku, +25 % doby trvání účinků a +1,5 zbroje na 30 sekund.

**Nově:** +25 % plochy účinku, +25 % doby trvání účinků a +1.5 zbroje na 30 sekund.

## items.json: util.overload.desc

**EN:** +35% damage, +15% weapon speed and +15% area for 30 seconds.

**Původně:** +35 % poškození, +15 % rychlosti zbraní a +15 % plochy účinku na 30 sekund.

**Nově:** +35 % poškození, +15 % rychlosti útoků a +15 % plochy účinku na 30 sekund.

## items.json: util.divine_super_combat_potion.desc

**EN:** +30% damage, +1.5 armour and +12% weapon speed for 60 seconds.

**Původně:** +30 % poškození, +1,5 zbroje a +12 % rychlosti zbraní na 60 sekund.

**Nově:** +30 % poškození, +1.5 zbroje a +12 % rychlosti útoků na 60 sekund.

## items.json: char.warrior.desc

**EN:** Starts with a bronze scimitar. Takes 1 less damage.

**Původně:** Začíná s Bronze scimitar. Každý zásah způsobuje o 1 menší poškození.

**Nově:** Začíná s Bronze scimitar. Z každého zásahu utrpí o 1 menší poškození.

## items.json: char.hunter.desc

**EN:** Starts with a shortbow. Picks things up from 50% further away.

**Původně:** Začíná se Shortbow. Sbírá předměty z o 50 % větší vzdálenosti.

**Nově:** Začíná se Shortbow. Dosah sbírání má o 50 % větší.

## items.json: char.berserker.desc

**EN:** Starts with a bronze 2h sword. Takes 0.5 less damage and hits back for 3.

**Původně:** Začíná s Bronze 2h sword. Utrpí o 0,5 menší poškození a vrací útočníkovi 3 poškození.

**Nově:** Začíná s Bronze 2h sword. Utrpí o 0.5 menší poškození a vrací útočníkovi 3 poškození.

## items.json: char.shayzien_soldier.desc

**EN:** Starts with a bronze scimitar. Takes 0.5 less damage and heals 3 hitpoints a minute.

**Původně:** Začíná s Bronze scimitar. Utrpí o 0,5 menší poškození a obnoví 3 životy za minutu.

**Nově:** Začíná s Bronze scimitar. Utrpí o 0.5 menší poškození a obnoví 3 životy za minutu.

## items.json: char.armadyl_ranger.desc

**EN:** Starts with an Armadyl crossbow. Ranged weapons hit 10% harder, and projectiles fly 15% faster.

**Původně:** Začíná s Armadyl crossbow. Zbraně na dálku způsobují o 10 % větší poškození a projektily létají o 15 % rychleji.

**Nově:** Začíná s Armadyl crossbow. Zbraně Ranged způsobují o 10 % větší poškození a projektily létají o 15 % rychleji.

## items.json: char.elf_archer.desc

**EN:** Starts with a crystal bow. Moves 10% faster, and ranged weapons hit 5% harder.

**Původně:** Začíná s Crystal bow. Pohybuje se o 10 % rychleji a zbraně na dálku způsobují o 5 % větší poškození.

**Nově:** Začíná s Crystal bow. Pohybuje se o 10 % rychleji a zbraně Ranged způsobují o 5 % větší poškození.

## items.json: char.inquisitor.desc

**EN:** Made for Phosani's Nightmare, and everyone plays them there, and nowhere else: starts with the Armadyl crossbow, moves 20% faster and has 20% more hitpoints.

**Původně:** Určen výhradně pro Phosani’s Nightmare, kde za něj hrají všichni. Začíná s Armadyl crossbow, pohybuje se o 20 % rychleji a má o 20 % více životů.

**Nově:** Určen výhradně pro Phosani's Nightmare, kde za něj hrají všichni. Začíná s Armadyl crossbow, pohybuje se o 20 % rychleji a má o 20 % více životů.

## items.json: set.void_knight.bonus

**EN:** +10% damage

**Původně:** +10% poškození

**Nově:** +10 % poškození

## items.json: set.virtus.bonus

**EN:** auras and Ancient spells cover 20% more area

**Původně:** aury a starověká kouzla zasahují o 20 % větší plochu

**Nově:** aury a kouzla Ancient Magicks zasahují o 20 % větší plochu

## items.json: passive.tome_of_fire.effect

**EN:** weapon speed

**Původně:** rychlost zbraní

**Nově:** rychlost útoků

## items.json: passive.divine_rune_pouch.desc

**EN:** One more weapon slot, for a magic weapon. Magic weapons are offered whatever your style.

**Původně:** Jedna další pozice pro magickou zbraň. Magické zbraně se nabízejí bez ohledu na váš bojový styl.

**Nově:** Jedna další pozice pro zbraň Magic. Zbraně Magic se nabízejí bez ohledu na váš bojový styl.

## items.json: passive.divine_rune_pouch.effect

**EN:** magic weapon slot

**Původně:** pozice pro magickou zbraň

**Nově:** pozice pro zbraň Magic

## items.json: passive.ancient_sceptre.desc

**EN:** Auras and Ancient spells cover more ground.

**Původně:** Aury a starověká kouzla zasahují větší plochu.

**Nově:** Aury a kouzla Ancient Magicks zasahují větší plochu.

## items.json: powerup.pumpkin.desc

**EN:** A treat or a trick.

**Původně:** Pamlsek, nebo žertík.

**Nově:** Odměna, nebo žertík.

## items.json: shop.strength.desc

**EN:** +5% damage

**Původně:** +5% poškození

**Nově:** +5 % poškození

## items.json: shop.prayer.desc

**EN:** Heal 1.5 hitpoints a minute

**Původně:** Obnovíte 1,5 života za minutu

**Nově:** Obnovíte 1.5 života za minutu

## items.json: shop.attack.desc

**EN:** Weapons 2.5% faster

**Původně:** Zbraně jsou o 2,5 % rychlejší

**Nově:** Zbraně jsou o 2.5 % rychlejší

## items.json: shop.firemaking.desc

**EN:** Banish one weapon, passive or item a run

**Původně:** Jednou za výpravu vyřadíte jednu zbraň, pasivní schopnost nebo předmět

**Nově:** Jednou za výpravu vyřadíte zbraň, pasivní předmět nebo předmět z truhly

## items.json: shop.woodcutting.desc

**EN:** +15% melee knockback

**Původně:** +15 % odhození zblízka

**Nově:** +15 % k odhození při Melee

## items.json: shop.crafting.desc

**EN:** One more passive slot

**Původně:** Jedna další pozice pro pasivní schopnost

**Nově:** Jedna další pozice pro pasivní předmět

## items.json: shop.runecraft.desc

**EN:** +15% power-up drops

**Původně:** +15 % četnosti bonusů

**Nově:** +15 % k četnosti padání bonusů

## ui-misc.json: armoury.to_unlock

**EN:** {task} to unlock

**Původně:** {task} k odemknutí

**Nově:** {task} a odemkněte vylepšení.

## ui-misc.json: canvas.controls.highlight

**EN:** Move the highlight, on menus and level ups

**Původně:** Pohyb výběru v nabídkách a při postupu na vyšší úroveň

**Nově:** Přesouvat výběr v nabídkách a při postupu na vyšší úroveň

## ui-misc.json: canvas.round_heal

**EN:** Heals {times} as much in round {round}.

**Původně:** Násobek léčení v kole {round}: {times}.

**Nově:** V kole {round} se léčení násobí {times}.

## ui-misc.json: canvas.round_hit

**EN:** Hits {times} as hard in round {round}.

**Původně:** Násobek poškození v kole {round}: {times}.

**Nově:** V kole {round} se poškození násobí {times}.

## ui-misc.json: canvas.style.magic

**EN:** magic

**Původně:** magic

**Nově:** Magic

## ui-misc.json: canvas.style.melee

**EN:** melee

**Původně:** melee

**Nově:** Melee

## ui-misc.json: canvas.style.ranged

**EN:** ranged

**Původně:** ranged

**Nově:** Ranged

## ui-misc.json: chest.carried

**EN:** You have {n} already; they stack.

**Původně:** Už máte {n}; lze je skládat na sebe.

**Nově:** Už máte {n}; ukládají se do jedné pozice.

## ui-misc.json: chest.equip

**EN:** Equip

**Původně:** Vybavit

**Nově:** Nasadit

## ui-misc.json: collection.evolutions

**EN:** Evolutions

**Původně:** Evoluce

**Nově:** Vývoje

## ui-misc.json: collection.evolution_intro

**EN:** Max a weapon and own its passive, and the next level up can evolve it.

**Původně:** Vylepšete zbraň na maximum a získejte příslušnou pasivní schopnost. Při dalším postupu na vyšší úroveň ji můžete vyvinout.

**Nově:** Vylepšete zbraň na maximum a získejte příslušný pasivní předmět. Při dalším postupu na vyšší úroveň ji můžete vyvinout.

## ui-misc.json: coop.endless_suffix

**EN:**  endless

**Původně:** nekonečný režim

**Nově:**  – nekonečný režim

## ui-misc.json: coop.hard_suffix

**EN:**  hard

**Původně:** těžký

**Nově:**  – těžký režim

## ui-misc.json: coop.not_ready

**EN:** Not ready

**Původně:** Není připraven

**Nově:** Nepřipraveno

## ui-misc.json: coop.open

**EN:** Open

**Původně:** VEŘEJNÁ

**Nově:** Veřejná

## ui-misc.json: coop.rooms_full

**EN:** All rooms are taken right now. Try again when one opens.

**Původně:** Všechny místnosti jsou plné. Zkuste to znovu, až se některá uvolní.

**Nově:** Momentálně nelze vytvořit další místnost. Zkuste to znovu, až se některá uvolní.

## ui-misc.json: save.other_tab_body_2

**EN:** Or play without saving: what you earn here lasts until that tab closes or this one reloads.

**Původně:** Nebo hrajte bez ukládání: získaný postup zůstane jen do zavření či opětovného načtení této karty.

**Nově:** Nebo hrajte bez ukládání: zdejší postup zůstane jen do zavření druhé karty nebo opětovného načtení této karty.

## ui-misc.json: save.newer_title

**EN:** Your save is from a newer version

**Původně:** Vaše uložení je z novější verze

**Nově:** Uložená hra je z novější verze

## ui-misc.json: save.newer_body

**EN:** It was saved by{saved} Run Escape, and this is v{version}, which would undo what's new in it. So this one won't save.

**Původně:** Uložení pochází z {saved} Run Escape, zatímco tato hra je v{version}. Uložením by se ztratila novější data, proto tato verze nebude ukládat.

**Nově:** Postup uložila{saved} Run Escape. Toto je v{version}, která by smazala novější data. Proto teď nebude ukládat.

## ui-misc.json: save.version_of

**EN:**  v{version} of

**Původně:** v{version} hry

**Nově:**  verze v{version} hry

## ui-misc.json: save.a_newer

**EN:**  a newer

**Původně:**  novější

**Nově:**  novější verze hry

## ui-misc.json: save.newer_anyway_warning

**EN:**  If it doesn't come, save anyway: you lose what was new in your save, and nothing else.

**Původně:** Pokud nová verze není dostupná, můžete přesto uložit. Ztratí se tím ale data z novější verze; ostatní postup zůstane zachovaný.

**Nově:**  Pokud nová verze není dostupná, můžete přesto uložit. Ztratí se jen data přidaná v novější verzi.

## ui-misc.json: save.unreadable_title

**EN:** Your save couldn't be read

**Původně:** Vaše uložení se nepodařilo přečíst

**Nově:** Uloženou hru se nepodařilo přečíst

## ui-misc.json: toast.round

**EN:** Round {round} begins! Monsters have {hp} the hitpoints and hit {damage} as hard, and caskets' gear comes +{gear}.

**Původně:** Začíná kolo {round}! Životy nepřátel: {hp}, poškození: {damage}. Vybavení z truhel má vylepšení +{gear}.

**Nově:** Začíná kolo {round}! Nepřátelé mají {hp} tolik životů a způsobují {damage} takové poškození. Vybavení z truhel má vylepšení +{gear}.

## ui-misc.json: cloud.link

**EN:** Link

**Původně:** Odkaz

**Nově:** Propojit

## ui-misc.json: cloud.delete

**EN:** Delete

**Původně:** Vymazat

**Nově:** Smazat

## ui-misc.json: cloud.button.choose

**EN:** pick which save to keep

**Původně:** vyberte, které uložení chcete zachovat

**Nově:** vyberte, který postup chcete zachovat

## ui-misc.json: notice.room_cleared

**EN:** Room cleared! Boss down in {time}: +{points} raid points, +{coins} coins.

**Původně:** Místnost vyčištěna! Boss padl za {time}. Získáváte {points} bodů za nájezd a {coins} mincí.

**Nově:** Místnost dokončena! Boss padl za {time}: +{points} bodů za nájezd, +{coins} mincí.

## ui-misc.json: notice.collection_log

**EN:** New item added to your collection log: {item}

**Původně:** Nový přírůstek do sbírky předmětů: {item}

**Nově:** Nově v nabídce Sbírka předmětů: {item}

## ui-misc.json: notice.turns_mostly

**EN:** {name} turns {colour}! Mostly {style} hurts it.

**Původně:** {name} mění barvu na {colour}! Nejlépe na něj platí {style}.

**Nově:** {name} mění barvu na {colour}! Největší poškození způsobuje {style}.

## ui.json: pause.coop_warning

**EN:** The run carries on while you're in here.

**Původně:** Hra pokračuje i během pobytu v nabídce.

**Nově:** Výprava pokračuje, i když jste v nabídce.

## ui.json: settings.coop_flag.name

**EN:** Co-op flag

**Původně:** Kooperativní vlajka

**Nově:** Vlajka v kooperaci

## ui.json: language.notice.body

**EN:** English is the only officially supported language. Other languages may be wrong or have translations missing, and they aren't verified in any way.

**Původně:** Angličtina je jediným oficiálně podporovaným jazykem. Jiné jazyky mohou být chybné nebo v nich chybí překlady a nejsou nijak ověřeny.

**Nově:** Oficiálně je podporována pouze angličtina. Ostatní překlady nejsou ověřené a mohou obsahovat chyby nebo chybějící texty.

## ui.json: settings.movement_prediction.desc

**EN:** Joining a co-op game, you move as soon as you press, then correct to the host

**Původně:** V kooperaci se pohyb zobrazí ihned po stisku a následně se opraví podle hostitele

**Nově:** V kooperaci se pohnete hned po stisku tlačítka. Hra pak vaši polohu upraví podle hostitele.

## ui.json: settings.save.alert_save_block

**EN:** The game isn't saving right now (see the notice on the title screen), so an imported save wouldn't be kept.

**Původně:** Hra se právě neukládá (viz upozornění na titulní obrazovce), takže importované uložení nebude zachováno.

**Nově:** Hra teď neukládá (viz upozornění na úvodní obrazovce). Importovaný postup by se proto neuložil.

## ui.json: settings.save.confirm_replace

**EN:** Replace your save ({current}) with this one ({imported})?

Export yours first if you want to keep it.

**Původně:** Nahradit současnou pozici ({current}) importovanou ({imported})?

Pokud si chcete současný postup nechat, nejprve si ho zálohujte.

**Nově:** Nahradit současný postup ({current}) importovaným ({imported})?

Pokud si chcete současný postup ponechat, nejprve ho exportujte.

## ui.json: settings.save.desc

**EN:** Kept in this browser. Export a copy to keep it safe or take it to another one.

**Původně:** Pokrok je uložen v tomto prohlížeči. Exportujte si zálohu nebo jej přeneste do jiného prohlížeče.

**Nově:** Postup se ukládá v tomto prohlížeči. Exportem ho zálohujete nebo přenesete do jiného prohlížeče.

## ui.json: settings.save.name

**EN:** Your progress

**Původně:** Váš pokrok

**Nově:** Váš postup

## ui.json: settings.unreadable.confirm_delete

**EN:** Delete the save from {when} for good?

**Původně:** Smazat uložení ze {when} navždy?

**Nově:** Trvale smazat uloženou hru z {when}?

## ui.json: settings.unreadable.delete

**EN:** Delete

**Původně:** Vymazat

**Nově:** Smazat

## ui.json: settings.unreadable.name

**EN:** Unreadable save

**Původně:** Nečitelné uložení

**Nově:** Nečitelná uložená hra

## ui.json: ui.character.favourite_off

**EN:** Make favourite

**Původně:** Přidat k oblíbeným

**Nově:** Nastavit jako oblíbeného

## ui.json: ui.character.might_find

**EN:** might find the 

**Původně:** Lze získat:

**Nově:** Možná kořist: 

## ui.json: ui.common.to_unlock

**EN:** to unlock

**Původně:** odemknout

**Nově:** k odemknutí

## ui.json: ui.endless.tooltip.open

**EN:** Round after round, each tougher than the last, until you fall. Your weapons, passives and gear keep getting stronger too.

**Původně:** Jedno kolo za druhým, každé těžší než předchozí, dokud nepadnete. Stále sílí i vaše zbraně, pasivní schopnosti a vybavení.

**Nově:** Jedno kolo za druhým, každé těžší než předchozí, dokud nepadnete. Stále sílí i vaše zbraně, pasivní předměty a vybavení.

## ui.json: ui.expert.tooltip.open

**EN:** Hard mode, and the Nylocas only take damage from their own style: grey melee, green ranged, blue magic. Nylocas Vasilias changes colour. Bring all three. Twice the coins, and one of Lil' Zik's looks each clear.

**Původně:** Těžký režim s dalšími pravidly: šedé Nylocas zraní jen Melee, zelené Ranged a modré Magic. Nylocas Vasilias mění barvu, takže se hodí mít všechny tři styly. Za dokončení získáte dvojnásobek mincí a jednu podobu Lil' Zik.

**Nově:** Těžký režim s dalšími pravidly: šedé Nylocas zraní jen Melee, zelené Ranged a modré Magic. Nylocas Vasilias mění barvu. Vezměte si všechny tři styly. Za dokončení získáte dvojnásobek mincí a jednu podobu Lil' Zik.

## ui.json: ui.hint.keyboard

**EN:** WASD to move · weapons fire on their own · Esc to pause · M to mute

**Původně:** WASD pro pohyb · zbraně střílejí samy · Esc pro pozastavení · M pro ztlumení

**Nově:** WASD: pohyb · zbraně útočí automaticky · Esc: pauza · M: vypnutí zvuku

## ui.json: ui.hint.to_move

**EN:** to move

**Původně:** pohybovat se

**Nově:** pro pohyb

## ui.json: ui.hint.to_pause

**EN:** to pause

**Původně:** pozastavit

**Nově:** pro pozastavení

## ui.json: ui.hint.to_pick

**EN:** to pick

**Původně:** vybrat si

**Nově:** pro výběr

## ui.json: ui.hint.touch

**EN:** Drag anywhere to move · weapons fire on their own

**Původně:** Přetažením kamkoli se můžete pohybovat · zbraně střílejí samy

**Nově:** Tažením prstu se pohybujete · zbraně útočí automaticky

## ui.json: ui.hint.weapons_fire

**EN:** weapons fire on their own

**Původně:** zbraně střílejí samy od sebe

**Nově:** zbraně útočí automaticky

## ui.json: ui.hud.boss_cursed

**EN:**  Cursed: {attacks}

**Původně:** Prokletý: {attacks}

**Nově:**  Prokletí: {attacks}

## ui.json: ui.hud.boss_enraged

**EN:**  (enraged)

**Původně:** (rozzuřený)

**Nově:**  (rozzuřený)

## ui.json: ui.hud.boss_parasite

**EN:**  Parasite: {seconds}s

**Původně:** Parazit: {seconds} s

**Nově:**  Parazit: {seconds} s

## ui.json: ui.hud.boss_status.stunned

**EN:** Stunned!

**Původně:** Omráčení!

**Nově:** Omráčen!

## ui.json: ui.hud.evolves_with

**EN:** Evolves with: 

**Původně:** K vývoji potřebuje:

**Nově:** K vývoji potřebuje: 

## ui.json: ui.run.choice_countdown_label

**EN:** Party choosing

**Původně:** Výběr družiny

**Nově:** Družina vybírá

## ui.json: ui.run.choice_countdown_aria

**EN:** Party choosing. Next automatic choice in {seconds} seconds

**Původně:** Výběr družiny. Další automatická volba za {seconds} sekund

**Nově:** Družina vybírá. Další automatická volba za {seconds} sekund

## ui.json: ui.levelup.title.regular

**EN:** Congratulations, you've advanced a level!

**Původně:** Nová úroveň! Vyberte si odměnu.

**Nově:** Gratulujeme, dosáhli jste nové úrovně!

## ui.json: ui.levelup.title.spell

**EN:** Choose your Ancient spell!

**Původně:** Vyberte starověké kouzlo!

**Nově:** Vyberte si kouzlo Ancient Magicks!

## ui.json: ui.map.boss_fight_char

**EN:** Boss fight. You play as the {name}.

**Původně:** Boj s bossem. Hrajete za {name}.

**Nově:** Souboj s bossem. Hrajete za {name}.

## ui.json: ui.map.tab.dev

**EN:** Dev

**Původně:** Dev

**Nově:** Vývoj

## ui.json: ui.raid.survive_waves

**EN:** Survive the waves: {boss} in {time}

**Původně:** Přežijte vlny: {boss} v {time}

**Nově:** Přežijte vlny: {boss} za {time}

## ui.json: ui.result.down

**EN:**  · Down

**Původně:** · Na zemi

**Nově:**  · Na zemi

## ui.json: ui.result.left_run

**EN:**  · Left the run

**Původně:** · Opustil výpravu

**Nově:**  · Opustil výpravu

## ui.json: ui.result.new_gear

**EN:** New in the Armoury: {gear}

**Původně:** Nová zbroj: {gear}

**Nově:** Nově v nabídce Zbroj: {gear}

## ui.json: ui.result.new_trophies

**EN:** New in the Collection log: {trophies}

**Původně:** Nově ve sbírce předmětů: {trophies}

**Nově:** Nově v nabídce Sbírka předmětů: {trophies}

## ui.json: ui.result.party_bosses

**EN:** Party bosses

**Původně:** Bossové družiny

**Nově:** Bossové poražení družinou

## ui.json: ui.title.stat.best_level

**EN:** Best level

**Původně:** Nejlepší úroveň

**Nově:** Nejvyšší úroveň

## world.json: boss.dharok.enrage.message

**EN:** Dharok's wounds only make him angrier!

**Původně:** Každá rána jen přiživuje Dharokův vztek!

**Nově:** Dharok s každým zraněním zuří víc!

## world.json: enemy.king_black_dragon.spawn

**EN:** The King Black Dragon crawls out of his lair under the Lava Maze!

**Původně:** King Black Dragon vylézá ze svého doupěte pod lávovým bludištěm!

**Nově:** King Black Dragon vylézá z doupěte pod Lava Maze!

## world.json: enemy.vorkath.spawn

**EN:** Vorkath wakes, and rises from the ice of Ungael!

**Původně:** Vorkath se probouzí a vstává z ledu Ungaelu!

**Nově:** Vorkath se probouzí a vstává z ledu na Ungael!

## world.json: boss.vorkath.enrage.message

**EN:** Vorkath's undead fire burns brighter!

**Původně:** Vorkathův nemrtvý oheň hoří jasněji!

**Nově:** Vorkath chrlí stále jasnější nemrtvý oheň!

## world.json: enemy.elvarg.spawn

**EN:** Elvarg flies in from Crandor!

**Původně:** Elvarg přilétá z Crandoru!

**Nově:** Elvarg přilétá z Crandor!

## world.json: enemy.nezikchened.spawn

**EN:** Nezikchened claws his way up out of the Viyeldi caves!

**Původně:** Nezikchened se prodírá ven z jeskyní Viyeldi!

**Nově:** Nezikchened se drápe ven z Viyeldi caves!

## world.json: enemy.alchemical_hydra.spawn

**EN:** The Alchemical Hydra slithers out of its lair under Mount Karuulm!

**Původně:** Alchemical Hydra se plazí ze svého doupěte pod horou Karuulm!

**Nově:** Alchemical Hydra se plazí z doupěte pod Mount Karuulm!

## world.json: boss.pestilent_bloat.enrage.message

**EN:** The Pestilent Bloat's flies swarm!

**Původně:** Mouchy Pestilent Bloat se rojí!

**Nově:** Kolem Pestilent Bloat se rojí mouchy!

## world.json: enemy.sotetseg.spawn

**EN:** Sotetseg rises from the Theatre's maze!

**Původně:** Sotetseg vstává z bludiště divadla!

**Nově:** Sotetseg povstává z bludiště v Theatre of Blood!

## world.json: boss.sotetseg.enrage.message

**EN:** Sotetseg's eyes burn red!

**Původně:** Sotetsegovy oči hoří rudě!

**Nově:** Sotetseg má oči rudé jako oheň!

## world.json: boss.verzik_vitur.enrage.shout

**EN:** Oh I'm going to enjoy this...

**Původně:** Oh, tohle si užiju...

**Nově:** Ó, tohle si užiju…

## world.json: boss.kreearra.summonsAt.message.1pq4c6g

**EN:** Wingman Skree flies to Kree'arra's side!

**Původně:** Wingman Skree letí na Kree'arrovu stranu!

**Nově:** Wingman Skree přilétá na pomoc Kree'arra!

## world.json: boss.kreearra.summonsAt.message.1p1p25r

**EN:** Flockleader Geerin flies to Kree'arra's side!

**Původně:** Flockleader Geerin letí na stranu Kree'arry!

**Nově:** Flockleader Geerin přilétá na pomoc Kree'arra!

## world.json: boss.kreearra.summonsAt.message.rmp34u

**EN:** Flight Kilisa flies to Kree'arra's side!

**Původně:** Flight Kilisa letí na stranu Kree'arry!

**Nově:** Flight Kilisa přilétá na pomoc Kree'arra!

## world.json: enemy.kreearra.attack.message.1muf7vi

**EN:** Kree'arra whips up a gale! Keep moving!

**Původně:** Kree'arra rozdmýchává vichřici! Pokračujte v pohybu!

**Nově:** Kree'arra rozpoutává vichřici! Nezastavujte se!

## world.json: boss.nex.summonsAt.shout.1rz3w4o

**EN:** Fumus, don't fail me!

**Původně:** Fumusi, nezklam mě!

**Nově:** Fumus, nezklam mě!

## world.json: enemy.nex.attack.shout.8ejy5c

**EN:** There is... NO ESCAPE!

**Původně:** Není... ŽÁDNÝ ÚNIK!

**Nově:** Není… ÚNIKU!

## world.json: enemy.nex.attack.shout.kna275

**EN:** Let the virus flow through you!

**Původně:** Nechte virus proudit vámi!

**Nově:** Ať vámi proudí nákaza!

## world.json: boss.nex_shadow.summonsAt.shout.1qy0uj1

**EN:** Umbra, don't fail me!

**Původně:** Umbro, nezklam mě!

**Nově:** Umbra, nezklam mě!

## world.json: enemy.nex_shadow.attack.message.13x8jkg

**EN:** Shadows gather around you! Keep moving!

**Původně:** Kolem vás se shromažďují stíny! Pokračujte v pohybu!

**Nově:** Kolem vás se shromažďují stíny! Nezastavujte se!

## world.json: boss.nex_blood.summonsAt.shout.s78mld

**EN:** Cruor, don't fail me!

**Původně:** Cruore, nezklam mě!

**Nově:** Cruor, nezklam mě!

## world.json: boss.nex_ice.enrage.message

**EN:** Nex calls on the power of Zaros!

**Původně:** Nex využívá sílu Zarosu!

**Nově:** Nex využívá sílu boha Zaros!

## world.json: boss.nex_ice.enrage.shout

**EN:** NOW, THE POWER OF ZAROS!

**Původně:** TEĎ, SÍLA ZAROSU!

**Nově:** TEĎ, SÍLA BOHA ZAROS!

## world.json: enemy.nex_ice.attack.shout.1fv10md

**EN:** Die now, in a prison of ice!

**Původně:** Zemři hned, ve vězení z ledu!

**Nově:** Zemři v ledovém vězení!

## world.json: enemy.jaltok_jad_finale.spawn

**EN:** Three JalTok-Jads rise out of the lava!

**Původně:** Tři JalTok-Jads povstanou z lávy!

**Nově:** Z lávy povstávají tři JalTok-Jad!

## world.json: enemy.slash_bash.spawn

**EN:** Slash Bash lumbers out of the dark, reeking of disease!

**Původně:** Slash Bash vystupuje ze tmy, páchne nemocí!

**Nově:** Ze tmy se těžkopádně vynořuje Slash Bash. Páchne nákazou!

## world.json: boss.slash_bash.enrage.message

**EN:** Slash Bash retches. Bile everywhere!

**Původně:** Slash Bash zvrací. Žluč všude!

**Nově:** Slash Bash dáví. Všude je žluč!

## world.json: enemy.scammer.chat.duufrk

**EN:** Trade me your phat, get 2 back

**Původně:** dej mi svůj phat a dostaneš dva

**Nově:** dej mi svůj phat a dostaneš 2 zpátky

## world.json: enemy.f2p_mage.chat.dj82w2

**EN:** freeze

**Původně:** zmrazit

**Nově:** zmrzni

## world.json: enemy.tank.chat.1dqbdix

**EN:** lol 0s

**Původně:** lol samý nuly

**Nově:** lol samý 0

## world.json: enemy.tank.chat.1otxqkw

**EN:** no ko

**Původně:** ne ko

**Nově:** žádný KO

## world.json: enemy.wildy_mage.attack.shout.dj82w2

**EN:** freeze

**Původně:** zmrazit

**Nově:** zmrzni

## world.json: enemy.noob.chat.sh5dlu

**EN:** kill me durial!!

**Původně:** zabij mě, duriale!!

**Nově:** zabij mě, durial!!

## world.json: enemy.noob.chat.1btknlz

**EN:** durial ur a legend

**Původně:** duriale, ty jsi legenda

**Nově:** durial, ty jsi legenda

## world.json: enemy.obby_noob.chat.sh5dlu

**EN:** kill me durial!!

**Původně:** zabij mě, duriale!!

**Nově:** zabij mě, durial!!

## world.json: enemy.ranger_noob.chat.sh5dlu

**EN:** kill me durial!!

**Původně:** zabij mě, duriale!!

**Nově:** zabij mě, durial!!

## world.json: enemy.pk_wannabe.chat.1btknlz

**EN:** durial ur a legend

**Původně:** duriale, ty jsi legenda

**Nově:** durial, ty jsi legenda

## world.json: enemy.lms_pure.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.lms_zerker.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.lms_ranger.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.lms_mage.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.lms_med.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.lms_maxed.chat.1kcas5a

**EN:** 1 left?

**Původně:** zbývá jeden?

**Nově:** zbývá 1?

## world.json: enemy.ags_specer.spawn

**EN:** An AGS specer found a bloody key!

**Původně:** AGS specer našel krvavý klíč!

**Nově:** AGS specer našel Bloody key!

## world.json: boss.lms_dharok.enrage.message

**EN:** The Dharok's sweat is at 1 hitpoint and swinging!

**Původně:** Dharok's sweat má poslední život a pořád útočí!

**Nově:** Dharok's sweat má už jen 1 život a pořád útočí!

## world.json: enemy.zamorak_noob.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.zamorak_noob.chat.1o5myfr

**EN:** bandages at table

**Původně:** obvazy jsou na stole

**Nově:** Bandages jsou na stole

## world.json: enemy.zamorak_ranger.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.zamorak_ranger.chat.1o5myfr

**EN:** bandages at table

**Původně:** obvazy jsou na stole

**Nově:** Bandages jsou na stole

## world.json: enemy.zamorak_warrior.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.zamorak_warrior.chat.1o5myfr

**EN:** bandages at table

**Původně:** obvazy jsou na stole

**Nově:** Bandages jsou na stole

## world.json: enemy.zamorak_mage.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.zamorak_mage.chat.1o5myfr

**EN:** bandages at table

**Původně:** obvazy jsou na stole

**Nově:** Bandages jsou na stole

## world.json: enemy.zamorak_tank.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.zamorak_tank.chat.1o5myfr

**EN:** bandages at table

**Původně:** obvazy jsou na stole

**Nově:** Bandages jsou na stole

## world.json: enemy.saradomin_player.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: enemy.flag_carrier.spawn

**EN:** A Zamorak player has your flag! Catch the Flag carrier!

**Původně:** Hráč Zamorakova týmu má vaši vlajku! Chyťte ho!

**Nově:** Hráč Zamorakova týmu má vaši vlajku! Chyťte Flag carrier!

## world.json: enemy.catapult_crew.spawn

**EN:** The Zamorak catapult crew has you in its sights!

**Původně:** Obsluha Zamorakova katapultu vás má na mušce!

**Nově:** Catapult crew ze Zamorakova týmu vás má na mušce!

## world.json: boss.catapult_crew.enrage.message

**EN:** The catapult crew fires faster!

**Původně:** Obsluha katapultu střílí rychleji!

**Nově:** Catapult crew střílí rychleji!

## world.json: enemy.zamorak_tank_boss.chat.15d54fw

**EN:** bandage pls

**Původně:** obvaz pls

**Nově:** Bandages pls

## world.json: boss.zamorak_tank_boss.enrage.shout

**EN:** BANDAGE PLS

**Původně:** OBVAZ PLS

**Nově:** BANDAGES PLS

## world.json: enemy.purple_portal.shield

**EN:** The purple portal's shield has dropped!

**Původně:** Štít fialového portálu padl!

**Nově:** Štít portálu Purple portal padl!

## world.json: enemy.blue_portal.shield

**EN:** The blue portal's shield has dropped!

**Původně:** Štít modrého portálu padl!

**Nově:** Štít portálu Blue portal padl!

## world.json: enemy.yellow_portal.shield

**EN:** The yellow portal's shield has dropped!

**Původně:** Štít žlutého portálu padl!

**Nově:** Štít portálu Yellow portal padl!

## world.json: enemy.red_portal.shield

**EN:** The red portal's shield has dropped!

**Původně:** Štít červeného portálu padl!

**Nově:** Štít portálu Red portal padl!

## world.json: enemy.the_nightmare.spawn

**EN:** The Nightmare rises!

**Původně:** The Nightmare stoupá!

**Nově:** The Nightmare povstává!

## world.json: boss.the_nightmare.enrage.message

**EN:** The Nightmare is furious!

**Původně:** Nightmare je vzteky bez sebe!

**Nově:** The Nightmare zuří!

## world.json: enemy.the_nightmare.attack.message.1tgfbwr

**EN:** Husks hold you in place! Kill them!

**Původně:** Husks vás drží na místě! Zabijte je!

**Nově:** Husk vás drží na místě! Zabijte je!

## world.json: enemy.the_nightmare.attack.message.1lyk0i2

**EN:** Sleepwalkers! Kill them before they reach her!

**Původně:** Sleepwalkers! Zabijte je dřív, než se k ní dostanou!

**Nově:** Sleepwalker! Zabijte je, než se k ní dostanou!

## world.json: enemy.the_nightmare.attack.message.i42ky7

**EN:** More sleepwalkers! Kill them before they reach her!

**Původně:** Další Sleepwalkers! Zabijte je dřív, než k ní dojdou!

**Nově:** Další Sleepwalker! Zabijte je, než se k ní dostanou!

## world.json: boss.the_nightmare.intro.subtitle

**EN:** of Ashihama

**Původně:** z Ashihamy

**Nově:** z Ashihama

## world.json: enemy.phosanis_nightmare.spawn

**EN:** Phosani's Nightmare rises!

**Původně:** Phosani's Nightmare stoupá!

**Nově:** Phosani's Nightmare povstává!

## world.json: enemy.phosanis_nightmare.attack.message.1njewgo

**EN:** Husks run for you! Shoot them down before they hold you!

**Původně:** Běží na vás Husks! Sestřelte je, než vás zadrží!

**Nově:** Běží na vás Husk! Sestřelte je, než vás zadrží!

## world.json: enemy.phosanis_nightmare.attack.message.1lyk0i2

**EN:** Sleepwalkers! Kill them before they reach her!

**Původně:** Sleepwalkers! Zabijte je dřív, než se k ní dostanou!

**Nově:** Sleepwalker! Zabijte je, než se k ní dostanou!

## world.json: enemy.phosanis_nightmare.attack.message.i42ky7

**EN:** More sleepwalkers! Kill them before they reach her!

**Původně:** Další Sleepwalkers! Zabijte je dřív, než k ní dojdou!

**Nově:** Další Sleepwalker! Zabijte je, než se k ní dostanou!

## world.json: enemy.ba_ba.attack.message.8ldhqn

**EN:** Ba-Ba calls her brawlers!

**Původně:** Ba-Ba si volá rváče na pomoc!

**Nově:** Ba-Ba přivolává Baboon Brawler!

## world.json: boss.akkha.enrage.message

**EN:** Akkha's armour glows: he's furious!

**Původně:** Akkhova zbroj září. Zuří naplno!

**Nově:** Akkha zuří a jeho zbroj září!

## world.json: boss.akkha.akkha.shadows.message

**EN:** Shadows appear throughout the room! Kill one, the others are shielded once it's struck, and draw Akkha into its quarter.

**Původně:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte Akkhu do jeho čtvrtiny.

**Nově:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte bosse Akkha do uvolněné čtvrtiny.

## world.json: boss.akkha.akkha.shadows.endMessage

**EN:** Akkha's shadows are gone. He can be hurt anywhere again!

**Původně:** Akkhovy stíny zmizely. Znovu ho můžete zranit kdekoli!

**Nově:** Stíny zmizely. Akkha je znovu zranitelný v celé místnosti!

## world.json: boss.akkha.phases.phases.status.8b7zcu

**EN:** Akkha's shadows

**Původně:** Akkhovy stíny

**Nově:** Stíny bosse Akkha

## world.json: boss.akkha.phases.phases.status.17gfk15

**EN:** Akkha's fury

**Původně:** Akkhova zuřivost

**Nově:** Zuřivost bosse Akkha

## world.json: boss.akkha_ranged.enrage.message

**EN:** Akkha's armour glows: he's furious!

**Původně:** Akkhova zbroj září. Zuří naplno!

**Nově:** Akkha zuří a jeho zbroj září!

## world.json: boss.akkha_ranged.akkha.shadows.message

**EN:** Shadows appear throughout the room! Kill one, the others are shielded once it's struck, and draw Akkha into its quarter.

**Původně:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte Akkhu do jeho čtvrtiny.

**Nově:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte bosse Akkha do uvolněné čtvrtiny.

## world.json: boss.akkha_ranged.akkha.shadows.endMessage

**EN:** Akkha's shadows are gone. He can be hurt anywhere again!

**Původně:** Akkhovy stíny zmizely. Znovu ho můžete zranit kdekoli!

**Nově:** Stíny zmizely. Akkha je znovu zranitelný v celé místnosti!

## world.json: boss.akkha_ranged.phases.phases.status.8b7zcu

**EN:** Akkha's shadows

**Původně:** Akkhovy stíny

**Nově:** Stíny bosse Akkha

## world.json: boss.akkha_ranged.phases.phases.status.17gfk15

**EN:** Akkha's fury

**Původně:** Akkhova zuřivost

**Nově:** Zuřivost bosse Akkha

## world.json: boss.akkha_magic.enrage.message

**EN:** Akkha's armour glows: he's furious!

**Původně:** Akkhova zbroj září. Zuří naplno!

**Nově:** Akkha zuří a jeho zbroj září!

## world.json: boss.akkha_magic.akkha.shadows.message

**EN:** Shadows appear throughout the room! Kill one, the others are shielded once it's struck, and draw Akkha into its quarter.

**Původně:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte Akkhu do jeho čtvrtiny.

**Nově:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte bosse Akkha do uvolněné čtvrtiny.

## world.json: boss.akkha_magic.akkha.shadows.endMessage

**EN:** Akkha's shadows are gone. He can be hurt anywhere again!

**Původně:** Akkhovy stíny zmizely. Znovu ho můžete zranit kdekoli!

**Nově:** Stíny zmizely. Akkha je znovu zranitelný v celé místnosti!

## world.json: boss.akkha_magic.phases.phases.status.8b7zcu

**EN:** Akkha's shadows

**Původně:** Akkhovy stíny

**Nově:** Stíny bosse Akkha

## world.json: boss.akkha_magic.phases.phases.status.17gfk15

**EN:** Akkha's fury

**Původně:** Akkhova zuřivost

**Nově:** Zuřivost bosse Akkha

## world.json: boss.akkha_enraged.enrage.message

**EN:** Akkha's armour glows: he's furious!

**Původně:** Akkhova zbroj září. Zuří naplno!

**Nově:** Akkha zuří a jeho zbroj září!

## world.json: boss.akkha_enraged.akkha.shadows.message

**EN:** Shadows appear throughout the room! Kill one, the others are shielded once it's struck, and draw Akkha into its quarter.

**Původně:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte Akkhu do jeho čtvrtiny.

**Nově:** V místnosti se objevují stíny! Vyberte jeden a zničte ho; po prvním zásahu se ostatní zaštítí. Pak nalákejte bosse Akkha do uvolněné čtvrtiny.

## world.json: boss.akkha_enraged.akkha.shadows.endMessage

**EN:** Akkha's shadows are gone. He can be hurt anywhere again!

**Původně:** Akkhovy stíny zmizely. Znovu ho můžete zranit kdekoli!

**Nově:** Stíny zmizely. Akkha je znovu zranitelný v celé místnosti!

## world.json: boss.akkha_enraged.phases.phases.status.8b7zcu

**EN:** Akkha's shadows

**Původně:** Akkhovy stíny

**Nově:** Stíny bosse Akkha

## world.json: boss.akkha_enraged.phases.phases.status.17gfk15

**EN:** Akkha's fury

**Původně:** Akkhova zuřivost

**Nově:** Zuřivost bosse Akkha

## world.json: enemy.zebak.attack.message.j7b69s

**EN:** Crocodiles climb onto the island!

**Původně:** Na ostrov vylézají krokodýli!

**Nově:** Na ostrov vylézají Crocodile!

## world.json: boss.zebak.phases.phases.status.1mdvsao

**EN:** Zebak's fury

**Původně:** Zebakova zuřivost

**Nově:** Zuřivost bosse Zebak

## world.json: boss.coenus.intro.subtitle

**EN:** The Head Menaphite Guard

**Původně:** Velitel menaphitské stráže

**Nově:** The Head Menaphite Guard

## world.json: boss.tob_pestilent_bloat.enrage.message

**EN:** The Pestilent Bloat's flies swarm!

**Původně:** Mouchy Pestilent Bloat se rojí!

**Nově:** Kolem Pestilent Bloat se rojí mouchy!

## world.json: enemy.tob_sotetseg.spawn

**EN:** Sotetseg rises from the Theatre's maze!

**Původně:** Sotetseg vstává z bludiště divadla!

**Nově:** Sotetseg povstává z bludiště v Theatre of Blood!

## world.json: boss.tob_sotetseg.enrage.message

**EN:** Sotetseg's eyes burn red!

**Původně:** Sotetsegovy oči hoří rudě!

**Nově:** Sotetseg má oči rudé jako oheň!

## world.json: boss.xarpus.exhumes.message

**EN:** Xarpus sinks into his pool! Stand on his exhumeds to smother them!

**Původně:** Xarpus se noří do jezírka! Postavte se na jeho exhumedy a zaduste je!

**Nově:** Xarpus se noří do jezírka! Stoupněte si na exhumedy a zaduste je!

## world.json: boss.xarpus.exhumes.endMessage

**EN:** Xarpus rises from his pool!

**Původně:** Xarpus vstává ze svého bazénu!

**Nově:** Xarpus se vynořuje z jezírka!

## world.json: boss.tob_verzik_vitur.enrage.shout

**EN:** Oh I'm going to enjoy this...

**Původně:** Oh, tohle si užiju...

**Nově:** Ó, tohle si užiju…

## world.json: map.lumbridge.desc

**EN:** Farm animals, goblins and the undead of Draynor Manor. Count Draynor wakes halfway, and the Wise Old Man comes at the end.

**Původně:** Hospodářská zvířata, goblini a nemrtví z Draynor Manor. V polovině se probouzí Count Draynor a na konci přichází Wise Old Man.

**Nově:** Hospodářská zvířata, Goblin a nemrtví z Draynor Manor. V polovině se probouzí Count Draynor, na konci přichází Wise Old Man.

## world.json: map.barrows.desc

**EN:** Crypt rats, spiders and bloodworms, ghouls, Mort'ton's afflicted and shades, and feral vampyres. The six Barrows brothers climb out of their crypts one by one, every two and a half minutes. Dharok comes last.

**Původně:** Krysy, pavouci a krvaví červi z krypt, ghúlové, nemocní a stíny z Mort’ton a divocí upíři. Šest bratrů Barrows postupně vystupuje z krypt, vždy po dvou a půl minutách. Dharok přichází poslední.

**Nově:** Crypt rat, Crypt spider a Bloodworm, Ghoul, Afflicted a Loar Shade z Mort'ton i Feral Vampyre. Šest bratrů Barrows postupně vystupuje z krypt, vždy po dvou a půl minutách. Dharok přichází poslední.

## world.json: map.wilderness.desc

**EN:** Revenants, bandits, dark warriors and chaos druids, the undead of the Graveyard of Shadows, hill giants and the Ankou. The Crazy archaeologist and the Chaos Fanatic, and the King Black Dragon at the end.

**Původně:** Revenanti, bandité, temní válečníci a druidové chaosu, nemrtví z Graveyard of Shadows, kopcoví obři a Ankou. Objeví se Crazy archaeologist a Chaos Fanatic, na konci King Black Dragon.

**Nově:** Revenanti, Bandit, Dark warrior a Chaos druid, nemrtví z Graveyard of Shadows, Hill Giant a Ankou. Objeví se Crazy archaeologist a Chaos Fanatic, na konci King Black Dragon.

## world.json: map.desert.desc

**EN:** Lizards, scorpions and jackals, desert bandits, kalphites out of their hive, crocodiles, mummies and locust riders. Desert Treasure's Fareed, Dessous and Damis come one by one, and the Kalphite Queen at the end.

**Původně:** Ještěři, štíři a šakali, pouštní bandité, kalphité z úlu, krokodýli, mumie a jezdci na sarančatech. Postupně přicházejí Fareed, Dessous a Damis z Desert Treasure, na konci Kalphite Queen.

**Nově:** Desert lizard, Scorpion a Jackal, Desert bandit, kalphité z úlu, Crocodile, Mummy a Locust rider. Postupně přicházejí Fareed, Dessous a Damis z Desert Treasure, na konci Kalphite Queen.

## world.json: map.fremennik.desc

**EN:** Rock crabs and wolves, cockatrices and yaks, trolls, basilisks and jellies, dagannoths and wallasalki, kurasks and rock lobsters. The three Dagannoth Kings come one by one, and Vorkath at the end.

**Původně:** Skalní krabi a vlci, kokatrice a jaci, trollové, bazilišci a slizové, dagannothové, wallasalki, kuraskové a skalní humři. Postupně přicházejí tři Dagannoth Kings, na konci Vorkath.

**Nově:** Rock crab, Wolf, Cockatrice a Yak, trollové, Basilisk, Jelly, Dagannoth, Wallasalki, Kurask a Rock lobster. Postupně přicházejí tři Dagannoth Kings, na konci Vorkath.

## world.json: map.karamja.desc

**EN:** Monkeys, snakes and jungle spiders, tribesmen, jogres and moss giants, lesser demons, and the TzHaar up out of the volcano. Elvarg, Nezikchened and Ket-Zek come one by one, and TzTok-Jad at the end.

**Původně:** Opice, hadi a džungloví pavouci, domorodci, jogrové a mechoví obři, menší démoni a TzHaar vystupující ze sopky. Postupně přicházejí Elvarg, Nezikchened a Ket-Zek, na konci TzTok-Jad.

**Nově:** Monkey, Snake a Jungle spider, Tribesman, Jogre a Moss giant, Lesser demon a TzHaar vystupující ze sopky. Postupně přicházejí Elvarg, Nezikchened a Ket-Zek, na konci TzTok-Jad.

## world.json: map.kourend.desc

**EN:** Guanic bats, swamp crabs and lizards, lizardmen and their brutes, bloodvelds, Xeric's deathly rangers, mages and skeletal mystics, and hydras. The Lizardman shaman, Sarachnis and Skotizo come one by one, and the Alchemical Hydra at the end.

**Původně:** Netopýři guanic, bahenní krabi a ještěři, ještěrci a jejich rváči, bloodveldové, Xericovi smrtící střelci, mágové a kostliví mystikové a hydry. Postupně přicházejí Lizardman shaman, Sarachnis a Skotizo, na konci Alchemical Hydra.

**Nově:** Guanic bat, Swamp crab a ještěři, Lizardman a Lizardman brute, Bloodveld, Xericovi Deathly ranger, Deathly mage a Skeletal mystic i Hydra. Postupně přicházejí Lizardman shaman, Sarachnis a Skotizo, na konci Alchemical Hydra.

## world.json: map.varlamore.desc

**EN:** Jerboas, pyre foxes and antelopes, blood jaguars, serpent shamans and jaguar warriors, naguas, the Fremennik warband, gryphons and minotaurs. The Manticore and the Shockwave and Javelin Colossi come one by one, and Sol Heredit at the end.

**Původně:** Tarbíci, ohnivé lišky a antilopy, krvaví jaguáři, hadí šamani a jaguáří válečníci, naguové, fremennická válečná družina, gryfové a minotauři. Postupně přicházejí Manticore, Shockwave Colossus a Javelin Colossus, na konci Sol Heredit.

**Nově:** Embertailed jerboa, Pyre fox a antilopy, Blood jaguar, Serpent shaman a Jaguar warrior, nagua, Fremennik warband, Gryphon a Minotaur. Postupně přicházejí Manticore, Shockwave Colossus a Javelin Colossus, na konci Sol Heredit.

## world.json: map.morytania.desc

**EN:** Ghasts, shades and zombies out of Mort Myre, vampyre juveniles and juvinates, werewolves, nail beasts and mutated bloodvelds, the Theatre of Blood's Nylocas and Darkmeyer's vyrewatch. Vanstrom Klause, the Pestilent Bloat and Sotetseg come one by one, and Verzik Vitur at the end.

**Původně:** Přízraky, stíny a zombie z Mort Myre, mladí upíři, vlkodlaci, nail beasts a zmutovaní bloodveldové, Nylocas z Theatre of Blood a vyrewatch z Darkmeyer. Postupně přicházejí Vanstrom Klause, Pestilent Bloat a Sotetseg, na konci Verzik Vitur.

**Nově:** Ghast, stíny a Zombie z Mort Myre, Vampyre juvenile a Vampyre juvinate, Werewolf, Nail beast a Mutated bloodveld, Nylocas z Theatre of Blood a Vyrewatch z Darkmeyer. Postupně přicházejí Vanstrom Klause, Pestilent Bloat a Sotetseg, na konci Verzik Vitur.

## world.json: map.god_wars.desc

**EN:** The armies of Bandos, Armadyl, Saradomin and Zamorak, at war with each other as much as with you: goblins, orks and cyclopes, aviansies, knights and priests, imps, hellhounds and bloodvelds, and the gods' spiritual warriors. Commander Zilyana, Kree'arra and K'ril Tsutsaroth come one by one, General Graardor leads a charge, and Nex comes at the end.

**Původně:** Armády bohů Bandos, Armadyl, Saradomin a Zamorak bojují mezi sebou i proti vám: goblini, orkové a kyklopové, aviansies, rytíři a kněží, rarášci, pekelní psi, bloodveldové a duchovní válečníci bohů. Postupně přicházejí Commander Zilyana, Kree'arra a K'ril Tsutsaroth, General Graardor vede útok a na konci dorazí Nex.

**Nově:** Armády bohů Bandos, Armadyl, Saradomin a Zamorak bojují mezi sebou i proti vám. Čekají vás Goblin, Ork, Cyclops, Aviansie, Knight of Saradomin, Saradomin priest, Imp, Hellhound, Bloodveld a Spiritual warrior. Postupně přicházejí Commander Zilyana, Kree'arra a K'ril Tsutsaroth, General Graardor vede útok a na konci dorazí Nex.

## world.json: map.prifddinas.desc

**EN:** The Gauntlet's crystalline rats, bats, spiders, scorpions, wolves, bears and dark beasts, the city's guards, the Iorwerth's warriors and archers and Zulrah's snakelings, and the corrupted ones late on. Zulrah, Zalcano and the Crystalline Hunllef come one by one, and the Corrupted Hunllef at the end.

**Původně:** Krystalové krysy, netopýři, pavouci, štíři, vlci, medvědi a temné bestie z The Gauntlet, městské stráže, válečníci a lučištníci rodu Iorwerth a Zulrahovi hadi; později i jejich zkažené varianty. Postupně přicházejí Zulrah, Zalcano a Crystalline Hunllef, na konci Corrupted Hunllef.

**Nově:** Tvorové z The Gauntlet: Crystalline rat, Crystalline bat, Crystalline spider, Crystalline scorpion, Crystalline wolf, Crystalline bear a Crystalline dark beast. Přidají se městští Guard, Iorwerth Warrior, Iorwerth Archer a Snakeling, později i varianty Corrupted. Postupně přicházejí Zulrah, Zalcano a Crystalline Hunllef, na konci Corrupted Hunllef.

## world.json: map.inferno.desc

**EN:** Mor Ul Rek's TzHaar and the Inferno's creatures: nibblers, Jal-MejRah bats, Jal-Ak blobs that split, Jal-ImKot that dig up near you, Jal-Xil, and Jal-Zek that raise the dead. JalTok-Jad, a Jal-Zek champion and a TzHaar-Ket champion come one by one, and three JalTok-Jads at once at the end.

**Původně:** TzHaar z Mor Ul Rek a tvorové z The Inferno: okusovači, netopýři Jal-MejRah, dělící se Jal-Ak, Jal-ImKot vyhrabávající se poblíž vás, Jal-Xil a Jal-Zek oživující mrtvé. Postupně přicházejí JalTok-Jad, šampion Jal-Zek a šampion TzHaar-Ket, na konci tři JalTok-Jad současně.

**Nově:** TzHaar z Mor Ul Rek a tvorové z The Inferno: Jal-Nib, netopýři Jal-MejRah, dělící se Jal-Ak, Jal-ImKot vyhrabávající se poblíž vás, Jal-Xil a Jal-Zek oživující mrtvé. Postupně přicházejí JalTok-Jad, Jal-Zek champion a TzHaar-Ket champion, na konci tři JalTok-Jad současně.

## world.json: map.grand_exchange.desc

**EN:** Spam bots, scammers, lurers, gold farmers, fake moderators and merchants. The Doubler, the Lure master and the Bot farmer turn up at random. Endless.

**Původně:** Spamovací boti, podvodníci, lákači do Wilderness, farmaři zlata, falešní moderátoři a obchodníci. Náhodně se objeví The Doubler, Lure master nebo Bot farmer. Nekonečný režim.

**Nově:** Spam bot, Scammer, Lurer, Gold farmer, Fake moderator a Merchant. Náhodně se objeví The Doubler, Lure master nebo Bot farmer. Nekonečný režim.

## world.json: map.east_varrock.desc

**EN:** The Wilderness, just past the ditch: free-to-play pkers in multi, clan noobs, rangers, mages, pures and tanks, in nothing members get, and more jumping the ditch behind you. A Clan leader, a Rune 2h pure and a Wildy mage turn up at random. Endless.

**Původně:** Wilderness hned za příkopem. F2P hráči vás loví v multi: klanoví nováčci, střelci, mágové, pures i tankové, všichni jen s nepředplatitelským vybavením. Další vám přeskakují příkop za zády. Náhodně dorazí Clan leader, Rune 2h pure nebo Wildy mage. Nekonečný režim.

**Nově:** Wilderness hned za příkopem. Loví vás hráči bez předplatného v oblasti multi: Clan noob, Ranger, Mage, Pure a Tank, všichni jen s vybavením bez předplatného. Další přeskakují příkop za vašimi zády. Náhodně dorazí Clan leader, Rune 2h pure nebo Wildy mage. Nekonečný režim.

## world.json: map.pest_control.desc

**EN:** The Void Knight's island, overrun: brawlers, ravagers, splatters that go off when they die, shifters that teleport to you, and spinners that heal the portals. All four portals open every few minutes, shielded at first; destroy them all for a master casket. Endless.

**Původně:** Ostrov Void Knight je v obležení: brawlers, ravagers, splatters vybuchující při smrti, shifters teleportující se přímo k vám a spinners léčící portály. Každých pár minut se otevřou všechny čtyři portály, zpočátku chráněné štíty. Zničte je všechny a získáte Reward casket (master). Nekonečný režim.

**Nově:** Ostrov Void Knight je v obležení: Brawler, Ravager, Splatter vybuchující při smrti, Shifter teleportující se přímo k vám a Spinner léčící portály. Každých pár minut se otevřou všechny čtyři portály, zpočátku chráněné štíty. Zničte je všechny a získáte Reward casket (master). Nekonečný režim.

## world.json: raid.supply.super_restore.name

**EN:** Super restore

**Původně:** Super obnova

**Nově:** Super restore

## world.json: raid.supply.divine_ranging.name

**EN:** Divine ranging potion

**Původně:** Božský pohybový lektvar

**Nově:** Divine ranging potion

## world.json: raid.supply.divine_magic.name

**EN:** Divine magic potion

**Původně:** Božský kouzelný lektvar

**Nově:** Divine magic potion

## world.json: event.mysterious_old_man.arrive

**EN:** A mysterious old man appears nearby.

**Původně:** Poblíž se objevil Mysterious old man.

**Nově:** Poblíž se objevil Mysterious Old Man.

## world.json: event.strange_plant.arrive

**EN:** A strange plant grows up nearby.

**Původně:** Poblíž vyrostla podivná rostlina.

**Nově:** Poblíž vyrostla Strange plant.

## world.json: event.strange_plant.leave

**EN:** The strange plant withers away.

**Původně:** Podivná rostlina uvadá.

**Nově:** Strange plant uvadá.

## world.json: event.strange_plant.message

**EN:** You eat a strange fruit: +30% movement speed, and poison can't touch you.

**Původně:** Snědli jste podivné ovoce: pohybujete se o 30 % rychleji a jed vám neublíží.

**Nově:** Snědli jste Strange fruit: +30 % k rychlosti pohybu a jed vám neublíží.

## world.json: event.strange_plant.effect_name

**EN:** Strange fruit

**Původně:** Zvláštní ovoce

**Nově:** Strange fruit

