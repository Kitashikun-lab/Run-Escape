# Run Escape – revidovaná čeština

Balíček pro verzi 0.30.0, commit `27c4f6a26b9b4a499225972be100366e823ae0f7`.

Rozbalte obsah ZIPu do kořene odpovídajícího zdrojového projektu Run Escape, slučte složky a nahraďte stejnojmenné soubory. Potom hru znovu spusťte nebo sestavte obvyklým postupem projektu. V nabídce jazyka vyberte Čeština.

Jde o balíček lokalizačních souborů, nikoli kompletní hru či instalátor. Obsahuje revidované české katalogy a podpůrné soubory z dodaného archivu, včetně českých fontů. Instalace závislostí a herních dat se řídí README původního projektu.

Rozsah revize a aktuálně provedené kontroly uvádí REVIZE-cestiny.md. Úplný seznam změněných textů je v ZMENY-prekladu.md.

Původní licence a autorská práva projektu zůstávají zachovány.
